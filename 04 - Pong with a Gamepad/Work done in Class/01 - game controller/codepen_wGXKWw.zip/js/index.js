var keyMove = 0;

window.onkeydown = function (e) {
  if (e.keyCode === 37) { // left
    keyMove = -4;
  }
  if (e.keyCode === 39) { // right
    keyMove = 4;
  }
}

window.onkeyup = function (e) {
  keyMove = 0;
}


function gameloop() {
  var gamepad = navigator.getGamepads()[0];
  var move = 0;
  
  if (gamepad) {
    move = gamepad.axes[0] * 4;
  }
  
  if (move === 0) {
    move = keyMove;
  }
  
  var left = $('#player').position().left;
  $('#player').css('left', left + move);
}

setInterval(gameloop, 30);