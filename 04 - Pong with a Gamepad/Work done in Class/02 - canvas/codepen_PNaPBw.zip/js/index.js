var canvas = document.querySelector('canvas');
var ctx = canvas.getContext('2d');

var i = 0;

function loop() {
  ctx.fillStyle = 'hsl(50, 50%, 50%)';
  ctx.fillRect(25 + i, 25 + i, 100, 100);
   
  i += 1;
}

setInterval(loop, 50);